<%@ page language="java" contentType="text/html; charset=UTF-8" pageEncoding="UTF-8"%>
<%@ page import ="java.io.PrintWriter" %>

<%@ page import="api.test_api" %>
<%@ page import="api.BoxOffice" %>
<%@ page import="java.util.ArrayList" %>
<%@ page import ="org.json.JSONArray" %>
<%@ page import ="org.json.JSONObject" %>
<!DOCTYPE html>
<html>
<head>
<meta charset="UTF-8">
<meta name="viewport" content = "width=device-width", initial-scale="1">
<link rel="stylesheet" href="css/bootstrap.css">
<script src="https://code.jquery.com/jquery-3.3.1.slim.min.js" integrity="sha384-q8i/X+965DzO0rT7abK41JStQIAqVgRVzpbzo5smXKp4YfRvH+8abtTE1Pi6jizo" crossorigin="anonymous"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.14.7/umd/popper.min.js" integrity="sha384-UO2eT0CpHqdSJQ6hJty5KVphtPhzWj9WO1clHTMGa3JDZwrnQq4sF86dIHNDz0W1" crossorigin="anonymous"></script>
<script src="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/js/bootstrap.min.js" integrity="sha384-JjSmVgyd0p3pXB1rRibZUAYoIIy6OrQ6VrjIEaFf/nJGzIxFDsf4x0xIM+B07jRM" crossorigin="anonymous"></script>
<script type="text/javascript" src="./ckeditor/ckeditor.js"></script>

<!--  <script src="https://cdn.ckeditor.com/ckeditor5/10.1.0/classic/ckeditor.js"></script> -->



<title>글쓰기</title>
</head>
<body>

	<%
		//로그인 된 사람을 처리하는 것.
		String userID = null;
		if(session.getAttribute("userID") != null){
			userID = (String) session.getAttribute("userID");
		}
	%>
	<nav class="navbar navbar-default">
		<div class="navbar-header">
			<button type="button" class="navbar-toggle collapsed"
				data-toggle="collapse" data-target="#bs-example-navbar-collapse-1"
				aria-expanded="false">
				<span class="icon-bar"></span>
				<span class="icon-bar"></span>
				<span class="icon-bar"></span>
				</button>
				<a class="navbar-brand" href="#">MovieNote</a>
		</div>
		
		<div class="collapse navbar-collapse" id="bs-example-navbar-collapse-1">
			<ul class="nav navbar-nav">
				<li><a href="main_page.jsp">BoxOffice</a></li>
				<li><a href="youtuberSuggestion.jsp">YoutuberSuggestion</a></li>
				<li><a href="bbs.jsp">Board</a></li>
				<li class="active"><a href="write.jsp">WriteNote</a></li>
			</ul>
			<% if(userID == null){
			%>
			<ul class="nav navbar-nav navbar-right">
				<li class="dropdown">
					<a href="#" class="dropdown-toggle"
						data-toggle="dropdown" role="button" aria-haspopup="true"
						aria-expanded="false">접속하기<span class="caret"></span></a>
						<ul class="dropdown-menu">
							<li><a href="login.jsp">로그인</a></li>
							<li><a href="join.jsp">회원가입</a></li>
						</ul>
				</li>
			</ul>
			<%
			}else{
				%>
				<ul class="nav navbar-nav navbar-right">
				<li class="dropdown">
					<a href="#" class="dropdown-toggle"
						data-toggle="dropdown" role="button" aria-haspopup="true"
						aria-expanded="false">회원관리<span class="caret"></span></a>
						<ul class="dropdown-menu">
							<li><a href="logoutAction.jsp">로그아웃</a></li>
						</ul>
				</li>
			</ul>
				<%
			}
			%>
			
			
			
		</div>
	</nav>
	
	
	
	<div class="container">
		<div class="row">
			<form method="post" action="writeAction.jsp">
				<table class="table table-strped" style="text-align:center; border:1px solid #dddddd">
					<thead>
						<tr>
							<th colspan="2" style ="background-color: #eeeeee; text-align: center;">게시판 글쓰기 양식</th>
						</tr>
					</thead>
					<tbody>
						<tr>
							<td>
								<input type="text" class="form-control" placeholder="글 제목" name="bbsTitle" maxlength="50">
							</td>
						</tr>
						 <tr>
							<td>
								<textarea  class="form-control" id="editor" placeholder="글 내용" name="bbsContent" style="height:350px"></textarea>
						
							</td>
						</tr> 
			
					</tbody>
				</table>
				<input type="submit" class="btn btn-primary pull-right" value="글쓰기">
			</form>
		

		
			
			
		</div>
		<div class="row">
		
		</div>
	</div>
	
	



	<script src="https://code.jquery.com/jquery-3.1.1.min.js"></script>
	<script src="js/bootstrap.js"></script>
	<script>

    CKEDITOR.replace('editor'
            , {height: 500                                                  
            });


</script>
	</script>
</body>
</html>                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                   tore.UnifiedTree.accept(UnifiedTree.java:118)
	at org.eclipse.core.internal.localstore.FileSystemResourceManager.delete(FileSystemResourceManager.java:364)
	at org.eclipse.core.internal.resources.ResourceTree.internalDeleteFolder(ResourceTree.java:361)
	at org.eclipse.core.internal.resources.ResourceTree.standardDeleteFolder(ResourceTree.java:813)
	at org.eclipse.core.internal.resources.Resource.unprotectedDelete(Resource.java:1773)
	at org.eclipse.core.internal.resources.Resource.delete(Resource.java:754)
	at org.eclipse.jdt.internal.core.builder.BatchImageBuilder.cleanOutputFolders(BatchImageBuilder.java:140)
	at org.eclipse.jdt.internal.core.builder.BatchImageBuilder.build(BatchImageBuilder.java:65)
	at org.eclipse.jdt.internal.core.builder.JavaBuilder.buildAll(JavaBuilder.java:275)
	at org.eclipse.jdt.internal.core.builder.JavaBuilder.build(JavaBuilder.java:192)
	at org.eclipse.core.internal.events.BuildManager$2.run(BuildManager.java:833)
	at org.eclipse.core.runtime.SafeRunner.run(SafeRunner.java:45)
	at org.eclipse.core.internal.events.BuildManager.basicBuild(BuildManager.java:220)
	at org.eclipse.core.internal.events.BuildManager.basicBuild(BuildManager.java:263)
	at org.eclipse.core.internal.events.BuildManager$1.run(BuildManager.java:316)
	at org.eclipse.core.runtime.SafeRunner.run(SafeRunner.java:45)
	at org.eclipse.core.internal.events.BuildManager.basicBuild(BuildManager.java:319)
	at org.eclipse.core.internal.events.BuildManager.basicBuildLoop(BuildManager.java:371)
	at org.eclipse.core.internal.events.BuildManager.build(BuildManager.java:392)
	at org.eclipse.core.internal.events.AutoBuildJob.doBuild(AutoBuildJob.java:154)
	at org.eclipse.core.internal.events.AutoBuildJob.run(AutoBuildJob.java:244)
	at org.eclipse.core.internal.jobs.Worker.run(Worker.java:63)
Contains: Could not delete: D:\MY\MY\apache-tomcat-8.5.45\webapps\Project\BBS\build\classes\user\UserDAO.class.
java.nio.file.AccessDeniedException: D:\MY\MY\apache-tomcat-8.5.45\webapps\Project\BBS\build\classes\user\UserDAO.class
	at sun.nio.fs.WindowsException.translateToIOException(Unknown Source)
	at sun.nio.fs.WindowsException.rethrowAsIOException(Unknown Source)
	at sun.nio.fs.WindowsException.rethrowAsIOException(Unknown Source)
	at sun.nio.fs.WindowsFileSystemProvider.implDelete(Unknown Source)
	at sun.nio.fs.AbstractFileSystemProvider.deleteIfExists(Unknown Source)
	at java.nio.file.Files.deleteIfExists(Unknown Source)
	at org.eclipse.core.internal.filesystem.local.LocalFile.internalDelete(LocalFile.java:223)
	at org.eclipse.core.internal.filesystem.local.LocalFile.internalDelete(LocalFile.java:251)
	at org.eclipse.core.internal.filesystem.local.LocalFile.delete(LocalFile.java:140)
	at org.eclipse.core.internal.localstore.DeleteVisitor.delete(DeleteVisitor.java:66)
	at org.eclipse.core.internal.localstore.DeleteVisitor.visit(DeleteVisitor.java:154)
	at org.eclipse.core.internal.localstore.UnifiedTree.accept(UnifiedTree.java:118)
	at org.eclipse.core.internal.localstore.FileSystemResourceManager.delete(FileSystemResourceManager.java:364)
	at org.eclipse.core.internal.resources.ResourceTree.internalDeleteFolder(ResourceTree.java:361)
	at org.eclipse.core.internal.resources.ResourceTree.standardDeleteFolder(ResourceTree.java:813)
	at org.eclipse.core.internal.resources.Resource.unprotectedDelete(Resource.java:1773)
	at org.eclipse.core.internal.resources.Resource.delete(Resource.java:754)
	at org.eclipse.jdt.internal.core.builder.BatchImageBuilder.cleanOutputFolders(BatchImageBuilder.java:140)
	at org.eclipse.jdt.internal.core.builder.BatchImageBuilder.build(BatchImageBuilder.java:65)
	at org.eclipse.jdt.internal.core.builder.JavaBuilder.buildAll(JavaBuilder.java:275)
	at org.eclipse.jdt.internal.core.builder.JavaBuilder.build(JavaBuilder.java:192)
	at org.eclipse.core.internal.events.BuildManager$2.run(BuildManager.java:833)
	at org.eclipse.core.runtime.SafeRunner.run(SafeRunner.java:45)
	at org.eclipse.core.internal.events.BuildManager.basicBuild(BuildManager.java:220)
	at org.eclipse.core.internal.events.BuildManager.basicBuild(BuildManager.java:263)
	at org.eclipse.core.internal.events.BuildManager$1.run(BuildManager.java:316)
	at org.eclipse.core.runtime.SafeRunner.run(SafeRunner.java:45)
	at org.eclipse.core.internal.events.BuildManager.basicBuild(BuildManager.java:319)
	at org.eclipse.core.internal.events.BuildManager.basicBuildLoop(BuildManager.java:371)
	at org.eclipse.core.internal.events.BuildManager.build(BuildManager.java:392)
	at org.eclipse.core.internal.events.AutoBuildJob.doBuild(AutoBuildJob.java:154)
	at org.eclipse.core.internal.events.AutoBuildJob.run(AutoBuildJob.java:244)
	at org.eclipse.core.internal.jobs.Worker.run(Worker.java:63)
Contains: Could not delete: D:\MY\MY\apache-tomcat-8.5.45\webapps\Project\BBS\build\classes\user.
!SUBENTRY 3 org.eclipse.core.resources 4 273 2019-12-14 13:02:14.624
!MESSAGE Problems encountered while deleting resources.
!SUBENTRY 4 org.eclipse.core.filesystem 4 273 2019-12-14 13:02:14.624
!MESSAGE Problems encountered while deleting files.
!SUBENTRY 5 org.eclipse.core.filesystem 4 273 2019-12-14 13:02:14.624
!MESSAGE Could not delete: D:\MY\MY\apache-tomcat-8.5.45\webapps\Project\BBS\build\classes\user\User.class.
!STACK 0
java.nio.file.AccessDeniedException: D:\MY\MY\apache-tomcat-8.5.45\webapps\Project\BBS\build\classes\user\User.class
	at sun.nio.fs.WindowsException.translateToIOException(Unknown Source)
	at sun.nio.fs.WindowsException.rethrowAsIOException(Unknown Source)
	at sun.nio.fs.WindowsException.rethrowAsIOException(Unknown Source)
	at sun.nio.fs.WindowsFileSystemProvider.implDelete(Unknown Source)
	at sun.nio.fs.AbstractFileSystemProvider.deleteIfExists(Unknown Source)
	at java.nio.file.Files.deleteIfExists(Unknown Source)
	at org.eclipse.core.internal.filesystem.local.LocalFile.internalDelete(LocalFile.java:223)
	at org.eclipse.core.internal.filesystem.local.LocalFile.internalDelete(LocalFile.java:251)
	at org.eclipse.core.internal.filesystem.local.LocalFile.delete(LocalFile.java:140)
	at org.eclipse.core.internal.localstore.DeleteVisitor.delete(DeleteVisitor.java:66)
	at org.eclipse.core.internal.localstore.DeleteVisitor.visit(DeleteVisitor.java:154)
	at org.eclipse.core.internal.localstore.UnifiedTree.accept(UnifiedTree.java:118)
	at org.eclipse.core.internal.localstore.FileSystemResourceManager.delete(FileSystemResourceManager.java:364)
	at org.eclipse.core.internal.resources.ResourceTree.internalDeleteFolder(ResourceTree.java:361)
	at org.eclipse.core.internal.resources.ResourceTree.standardDeleteFolder(ResourceTree.java:813)
	at org.eclipse.core.internal.resources.Resource.unprotectedDelete(Resource.java:1773)
	at org.eclipse.core.internal.resources.Resource.delete(Resource.java:754)
	at org.eclipse.jdt.internal.core.builder.BatchImageBuilder.cleanOutputFolders(BatchImageBuilder.java:140)
	at org.eclipse.jdt.internal.core.builder.BatchImageBuilder.build(BatchImageBuilder.java:65)
	at org.eclipse.jdt.internal.core.builder.JavaBuilder.buildAll(JavaBuilder.java:275)
	at org.eclipse.jdt.internal.core.builder.JavaBuilder.build(JavaBuilder.java:192)
	at org.eclipse.core.internal.events.BuildManager$2.run(BuildManager.java:833)
	at org.eclipse.core.runtime.SafeRunner.run(SafeRunner.java:45)
	at org.eclipse.core.internal.events.BuildManager.basicBuild(BuildManager.java:220)
	at org.eclipse.core.internal.events.BuildManager.basicBuild(BuildManager.java:263)
	at org.eclipse.core.internal.events.BuildManager$1.run(BuildManager.java:316)
	at org.eclipse.core.runtime.SafeRunner.run(SafeRunner.java:45)
	at org.eclipse.core.internal.events.BuildManager.basicBuild(BuildManager.java:319)
	at org.eclipse.core.internal.events.BuildManager.basicBuildLoop(BuildManager.java:371)
	at org.eclipse.core.internal.events.BuildManager.build(BuildManager.java:392)
	at org.eclipse.core.internal.events.AutoBuildJob.doBuild(AutoBuildJob.java:154)
	at org.eclipse.core.internal.events.AutoBuildJob.run(AutoBuildJob.java:244)
	at org.eclipse.core.internal.jobs.Worker.run(Worker.java:63)
!SUBENTRY 5 org.eclipse.core.filesystem 4 273 2019-12-14 13:02:14.624
!MESSAGE Could not delete: D:\MY\MY\apache-tomcat-8.5.45\webapps\Project\BBS\build\classes\user\UserDAO.class.
!STACK 0
java.nio.file.AccessDeniedException: D:\MY\MY\apache-tomcat-8.5.45\webapps\Project\BBS\build\classes\user\UserDAO.class
	at sun.nio.fs.WindowsException.translateToIOException(Unknown Source)
	at sun.nio.fs.WindowsException.rethrowAsIOException(Unknown Source)
	at sun.nio.fs.WindowsException.rethrowAsIOException(Unknown Source)
	at sun.nio.fs.WindowsFileSystemProvider.implDelete(Unknown Source)
	at sun.nio.fs.AbstractFileSystemProvider.deleteIfExists(Unknown Source)
	at java.nio.file.Files.deleteIfExists(Unknown Source)
	at org.eclipse.core.internal.filesystem.local.LocalFile.internalDelete(LocalFile.java:223)
	at org.eclipse.core.internal.filesystem.local.LocalFile.internalDelete(LocalFile.java:251)
	at org.eclipse.core.internal.filesystem.local.LocalFile.delete(LocalFile.java:140)
	at org.eclipse.core.internal.localstore.DeleteVisitor.delete(DeleteVisitor.java:66)
	at org.eclipse.core.internal.localstore.DeleteVisitor.visit(DeleteVisitor.java:154)
	at org.eclipse.core.internal.localstore.UnifiedTree.accept(UnifiedTree.java:118)
	at org.eclipse.core.internal.localstore.FileSystemResourceManager.delete(FileSystemResourceManager.java:364)
	at org.eclipse.core.internal.resources.ResourceTree.internalDeleteFolder(ResourceTree.java:361)
	at org.eclipse.core.internal.resources.ResourceTree.standardDeleteFolder(ResourceTree.java:813)
	at org.eclipse.core.internal.resources.Resource.unprotectedDelete(Resource.java:1773)
	at org.eclipse.core.internal.resources.Resource.delete(Resource.java:754)
	at org.eclipse.jdt.internal.core.builder.BatchImageBuilder.cleanOutputFolders(BatchImageBuilder.java:140)
	at org.eclipse.jdt.internal.core.builder.BatchImageBuilder.build(BatchImageBuilder.java:65)
	at org.eclipse.jdt.internal.core.builder.JavaBuilder.buildAll(JavaBuilder.java:275)
	at org.eclipse.jdt.internal.core.builder.JavaBuilder.build(JavaBuilder.java:192)
	at org.eclipse.core.internal.events.BuildManager$2.run(BuildManager.java:833)
	at org.eclipse.core.runtime.SafeRunner.run(SafeRunner.java:45)
	at org.eclipse.core.internal.events.BuildManager.basicBuild(BuildManager.java:220)
	at org.eclipse.core.internal.events.BuildManager.basicBuild(BuildManager.java:263)
	at org.eclipse.core.internal.events.BuildManager$1.run(BuildManager.java:316)
	at org.eclipse.core.runtime.SafeRunner.run(SafeRunner.java:45)
	at org.eclipse.core.internal.events.BuildManager.basicBuild(BuildManager.java:319)
	at org.eclipse.core.internal.events.BuildManager.basicBuildLoop(BuildManager.java:371)
	at org.eclipse.core.internal.events.BuildManager.build(BuildManager.java:392)
	at org.eclipse.core.internal.events.AutoBuildJob.doBuild(AutoBuildJob.java:154)
	at org.eclipse.core.internal.events.AutoBuildJob.run(AutoBuildJob.java:244)
	at org.eclipse.core.internal.jobs.Worker.run(Worker.java:63)
!SUBENTRY 5 org.eclipse.core.filesystem 4 273 2019-12-14 13:02:14.624
!MESSAGE Could not delete: D:\MY\MY\apache-tomcat-8.5.45\webapps\Project\BBS\build\classes\user.

!ENTRY org.eclipse.jdt.core 4 4 2019-12-14 13:02:14.663
!MESSAGE JavaBuilder handling CoreException
!STACK 1
org.eclipse.core.runtime.CoreException: Could not write file: D:\MY\MY\apache-tomcat-8.5.45\webapps\Project\BBS\build\classes\api\BoxOffice.class.
	at org.eclipse.core.internal.filesystem.Policy.error(Policy.java:48)
	at org.eclipse.core.internal.filesystem.local.LocalFile.openOutputStream(LocalFile.java:434)
	at org.eclipse.core.internal.localstore.FileSystemResourceManager.write(FileSystemResourceManager.java:1164)
	at org.eclipse.core.internal.resources.File.internalSetContents(File.java:306)
	at org.eclipse.core.internal.resources.File.setContents(File.java:342)
	at org.eclipse.core.internal.resources.File.setContents(File.java:437)
	at org.eclipse.jdt.internal.core.builder.AbstractImageBuilder.writeClassFileContents(AbstractImageBuilder.java:895)
	at org.eclipse.jdt.internal.core.builder.AbstractImageINDX( 	 �yy	            (   8  �       ��                  }�     � �     "�     1�����<Y���'X����1����       �               5 0 9 0 d e 2 f d d 1 f 0 0 1 a 1 a 4 5 e 3 9 6 8 4 c 5 b 9 e 3       }�     h R     "�     1�����<Y���'X����1����       �              5 0 9 0 D E ~ 1 5 5 1 ��     � �     "�     Nm���0�����o����Nm���        �               9 0 7 b 5 d 1 b e 3 1 f 0 0 1 a 1 a 4 5 e 3 9 6 8 4 c 5 b 9 e 3       ��     h R     "�     Nm���0���� o����Nm���        �              9 0 7 B 5 D ~ 1 5 5 1 ��     � �     "�     ���%�� 2S$����%�����%��       E               9 0 a 1 c a 6 3 e 4 1 f 0 0 1 a 1 a 4 5 e 3 9 6 8 4 c 5 b 9 e 3       ��     h R     "�     ���%�� 2S$����%�����%��       E              9 0 A 1 C A ~ 1 5 5 1 '�     � �     "�     ED�b���X�4��f��b��ED�b��       �               a 0 a 8 2 a 5 a 5 5 1 e 0 0 1 a 1 d d 0 a 0 1 e 9 e c 9 e 8 f 1       '�     h R     "�     ED�b���X�4� f��b��ED�b��       �              A 0 A 8 2 A ~ 1                     0 a 0 1 e 9 e c 9 e 8 f 1       '�     h R     "�     ED�b���X�4��f��b��ED�b��       �              A 0 A 8 2 A ~ 1                     "�     ED�b���X�4��f��b��ED�b��       �              A 0 A 8 2 A ~ 1                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                               setUTCDate(date)
  * @memberOf Date
  * @returns {Number}
  * @param {Number} date
  * @since Standard ECMA-262 3rd. Edition
  * @since Level 2 Document Object Model Core Definition.
 */
Date.prototype.setUTCDate = function(date){return 0;};

/**
  * function setMonth(month,date)
  * @memberOf Date
  * @returns {Number}
  * @param {Number} date
  * @param {Number} month
  * @since Standard ECMA-262 3rd. Edition
  * @since Level 2 Document Object Model Core Definition. 
 */
Date.prototype.setMonth = function(month,date){return 1;};
/**
  * function setUTCMonth(month,date)
  * @memberOf Date
  * @returns {Number}
  * @param {Number} date
  * @param {Number} month
  * @since Standard ECMA-262 3rd. Edition
  * @since Level 2 Document Object Model Core Definition.
 */
Date.prototype.setUTCMonth = function(month,date){return 1;};
/**
  * function setFullYear(month,date)
  * @memberOf Date
  * @returns {Number}
  * @param {Number} date
  * @param {Number} month
  * @param {Number} year
  * @since Standard ECMA-262 3rd. Edition
  * @since Level 2 Document Object Model Core Definition. 
 */
Date.prototype.setFullYear = function(year, month,date){return 0;};
/**
  * function setUTCFullYear(month,date)
  * @memberOf Date
  * @returns {Date}
  * @param {Number} date
  * @param {Number} month
  * @param {Number} year
  * @since Standard ECMA-262 3rd. Edition
  * @since Level 2 Document Object Model Core Definition.
 */
Date.prototype.setUTCFullYear = function(year, month,date){};
/**
 * function toUTCString()
 * @memberOf Date
 * @returns {String}
 * @since Standard ECMA-262 3rd. Edition
 * @since Level 2 Document Object Model Core Definition.
*/
Date.prototype.toUTCString = function(){return "";};

/**
  * Property NaN
  * @since   Standard ECMA-262 3rd. Edition 
  * @since   Level 2 Document Object Model Core Definition.  
 */
var NaN=0;
/**
  * Property Infinity
  * @since   Standard ECMA-262 3rd. Edition 
  * @since   Level 2 Document Object Model Core Definition.  
 */
var Infinity=0;
/**
  * function eval(s)
  * @param {String} s
  * @type Object
  * @returns {Object}
  * @since   Standard ECMA-262 3rd. Edition 
  * @since   Level 2 Document Object Model Core Definition.     
 */
function eval(s){return new Object();};

//@GINO: Bug 197987 (Temp Fix)
/**
  * Property debugger
  * @description Debugger keyword
 */
var debugger=null;

/**
 * Property undefined
 * @description undefined
*/
var undefined=null;

/**
  * function parseInt(s,radix)
  * @param {String} s
  * @param {Number} radix
  * @type Number
  * @returns {Number}
  * @since   Standard ECMA-262 3rd. Edition 
  * @since   Level 2 Document Object Model Core Definition.    
 */
function parseInt(s,radix){return 0;};
/**
  * function parseFloat(s)
  * @param {String} s
  * @type Number
  * @returns {Number}
  * @since   Standard ECMA-262 3rd. Edition 
  * @since   Level 2 Document Object Model Core Definition.   
 */
function parseFloat(s){return 0;};
/**
 * function escape(s)
 * @param {String} s
 * @type String
 * @returns {String}
 * @since   Standard ECMA-262 3rd. Edition 
 * @since   Level 2 Document Object Model Core Definition.   
*/
function escape(s){return "";};
/**
 * function unescape(s)
 * @param {String} s
 * @type String
 * @returns {String}
 * @since   Standard ECMA-262 3rd. Edition 
 * @since   Level 2 Document Object Model Core Definition.   
*/
function unescape(s){return "";};
/**
  * function isNaN(number)
  * @param {String} number
  * @type Boolean
  * @returns {Boolean}
  * @since   Standard ECMA-262 3rd. Edition 
  * @since   Level 2 Document Object Model Core Definition.  
 */
function isNaN(number){return false;};
/**
  * function isFinite(number)
  * @param {String} number
  * @type Boolean
  * @returns {Boolean}
  * @since   Standard ECMA-262 3rd. Edition 
  * @since   Level 2 Document Object Model Core Definition.    
 */
function isFinite(number){return false;};
/**
 * function decodeURI(encodedURI)
 * @param {String} encodedURI
 * @type String
 * @returns {String}
 * @since   Standard ECMA-262 3rd. Edition 
 * @since   Level 2 Document Object Model Core Definition.  
*/
function decodeURI(encodedURI){return "";};
/**
 * @param {String} uriComponent
 * @type String
 * @returns {String}
 * @since   Standard ECMA-262 3rd. Edition 
 * @since   Level 2 Document Object Model Core Definition.  
*/
function decodeURIComponent(uriComponent){return "";};
/**
 * function encodeURIComponent(uriComponent)
 * @param {String} uriComponent
 * @type String
 * @returns {String}
 * @since   Standard ECMA-262 3rd. Edition 
 * @since   Level 2 Document Object Model Core Definition.    
*/
function encodeURIComponent(uriComponent){return "";};

/**
 * function encodeURIComponent(URI)
 * @param {String} URI
 * @type String
 * @returns {String}
 * @since   Standard ECMA-262 3rd. Edition 
 * @since   Level 2 Document Object Model Core Definition.    
*/
function encodeURI(URI){return "";};

/**
  * Object Math(\s)
  * @super Object
  * @constructor
  * @memberOf Math
  * @since Standard ECMA-262 3rd. Edition
  * @since Level 2 Document Object Model Core Definition.
     
 */
function Math(){};
Math.prototype=new Object();
/**
  * Property E
  * @memberOf Math
  * @since   Standard ECMA-262 3rd. Edition 
  * @since   Level 2 Document Object Model Core Definition.    
 */
Math.E=0;
/**
  * Property LN10
  * @memberOf Math
  * @since   Standard ECMA-262 3rd. Edition 
  * @since   Level 2 Document Object Model Core Definition.    
 */
Math.LN10=0;
/**
  * Property LN2
  * @memberOf Math
  * @since   Standard ECMA-262 3rd. Edition 
  * @since   Level 2 Document Object Model Core Definition.
 */
Math.LN2=0;
/**
  * Property LOG2E
  * @memberOf Math
  * @since   Standard ECMA-262 3rd. Edition 
  * @since   Level 2 Document Object Model Core Definition.    
 */
Math.LOG2E=0;
/**
  * Property LOG10E
  * @memberOf Math
  * @since   Standard ECMA-262 3rd. Edition 
  * @since   Level 2 Document Object Model Core Definition. 
 */
Math.LOG10E=0;
/**
  * Property PI
  * @memberOf Math
  * @since   Standard ECMA-262 3rd. Edition 
  * @since   Level 2 Document Object Model Core Definition.  
 */
Math.PI=0;
/**
  * Property SQRT1_2
  * @memberOf Math
  * @since   Standard ECMA-262 3rd. Edition 
  * @since   Level 2 Document Object Model Core Definition.    
 */
Math.SQRT1_2=0;
/**
  * Property SQRT2
  * @memberOf Math
  * @since   Standard ECMA-262 3rd. Edition 
  * @since   Level 2 Document Object Model Core Definition. 
 */
Math.SQRT2=0;
/**
  * function abs(x)
  * @memberOf Math
  * @param {Number} x
  * @type Number
  * @returns {Number}
  * @since   Standard ECMA-262 3rd. Edition 
  * @since   Level 2 Document Object Model Core Definition.     
 */
Math.abs=function(x){return 0;};
/**
  * function acos(x)
  * @memberOf Math
  * @param {Number} x
  * @type Number
  * @returns {Number}
  * @since   Standard ECMA-262 3rd. Edition 
  * @since   Level 2 Document Object Model Core Definition.
 */
Math.acos=function(x){return 0;};
/**
  * function asin(x)
  * @memberOf Math
  * @param {Number} x
  * @type Number
  * @returns {Number}
  * @since   Standard ECMA-262 3rd. Edition 
  * @since   Level 2 Document Object Model Core Definition.  
 */
Math.asin=function(x){return 0;};
/**
  * function atan(x)
  * @memberOf Math
  * @param {Number} x
  * @type Number
  * @returns {Number}
  * @since   Standard ECMA-262 3rd. Edition 
  * @since   Level 2 Document Object Model Core Definition.
 */
Math.atan=function(x){return 0;};
/**
  * function atan2(x,y)
  * @memberOf Math
  * @param {Number} x
  * @param {Number} y
  * @type Number
  * @returns {Number}
  * @since   Standard ECMA-262 3rd. Edition 
  * @since   Level 2 Document Object Model Core Definition.  
 */
Math.atan2=function(x,y){return 0;};
/**
  * function ceil(x)
  * @memberOf Math
  * @param {Number} x
  * @type Number
  * @returns {Number}
  * @since   Standard ECMA-262 3rd. Edition 
  * @since   Level 2 Document Object Model Core Definition.    
 */
Math.ceil=function(x){return 0;};
/**
  * function cos(x)
  * @memberOf Math
  * @param {Number} x
  * @type Number
  * @returns {Number}
  * @since   Standard ECMA-262 3rd. Edition 
  * @since   Level 2 Document Object Model Core Definition.  
 */
Math.cos=function(x){return 0;};
/**
  * function exp(x)
  * @memberOf Math
  * @param {Number} x
  * @type Number
  * @returns {Number}
  * @since   Standard ECMA-262 3rd. Edition 
  * @since   Level 2 Document Object Model Core Definition. 
 */
Math.exp=function(x){return 0;};
/**
  * function floor(x)
  * @memberOf Math
  * @param {Number} x
  * @type Number
  * @returns {Number}
  * @since   Standard ECMA-262 3rd. Edition 
  * @since   Level 2 Document Object Model Core Definition.  
 */
Math.floor=function(x){return 0;};
/**
  * function log(x)
  * @memberOf Math
  * @param {Number} x
  * @type Number
  * @returns {Number}
  * @since   Standard ECMA-262 3rd. Edition 
  * @since   Level 2 Document Object Model Core Definition.    
 */
Math.log=function(x){return 0;};
/**
  * function max(arg)
  * @memberOf Math
  * @param {Number} args
  * @type Number
  * @returns {Number}
  * @since   Standard ECMA-262 3rd. Edition 
  * @since   Level 2 Document Object Model Core Definition.  
 */
Math.max=function(args){return 0;};
/**
  * function min(arg)
  * @memberOf Math
  * @param {Number} args
  * @type Number
  * @returns {Number}
  * @since   Standard ECMA-262 3rd. Edition 
  * @since   Level 2 Document Object Model Core Definition.    
 */
Math.min=function(args){return 0;};
/**
  * function pow(x,y)
  * @memberOf Math
  * @param {Number} x
  * @param {Number} y
  * @type Number
  * @returns {Number}
  * @since   Standard ECMA-262 3rd. Edition 
  * @since   Level 2 Document Object Model Core Definition.    
 */
Math.pow=function(x,y){return 0;};
/**
  * function pow()
  * @memberOf Math
  * @type Number
  * @returns {Number}
  * @since   Standard ECMA-262 3rd. Edition 
  * @since   Level 2 Document Object Model Core Definition.     
 */
Math.random=function(){return 0;};
/**
  * function round(x)
  * @memberOf Math
  * @param {Number} x
  * @type Number
  * @returns {Number}
  * @since   Standard ECMA-262 3rd. Edition 
  * @since   Level 2 Document Object Model Core Definition.   
 */
Math.round=function(x){return 0;};
/**
  * function sin(x)
  * @memberOf Math
  * @param {Number} x
  * @type Number
  * @returns {Number}
  * @since   Standard ECMA-262 3rd. Edition 
  * @since   Level 2 Document Object Model Core Definition.    
 */
Math.sin=function(x){return 0;};
/**
  * function sqrt(x)
  * @memberOf Math
  * @param {Number} x
  * @type Number
  * @returns {Number}
  * @since   Standard ECMA-262 3rd. Edition 
  * @since   Level 2 Document Object Model Core Definition.     
 */
Math.sqrt=function(x){return 0;};
/**
  * function tan(x)
  * @memberOf Math
  * @param {Number} x
  * @type Number
  * @returns {Number}
  * @since   Standard ECMA-262 3rd. Edition 
  * @since   Level 2 Document Object Model Core Definition.    
 */
Math.tan=function(x){return 0;};
/**
  * Object RegExp()
  * @super Object
  * @constructor
  * @memberOf RegExp
  * @since Standard ECMA-262 3rd. Edition
  * @since Level 2 Document Object Model Core Definition.
 */
function RegExp(){};
RegExp.prototype=new Object();
/**
  * function exec(string)
  * @param {String} string
  * @returns {Array}
  * @type Array
  * @memberOf RegExp
  * @since Standard ECMA-262 3rd. Edition
  * @since Level 2 Document Object Model Core Definition.
 */
RegExp.prototype.exec=function(string){return [];};
/**
  * function test(string)
  * @param {String} string
  * @returns {Boolean}
  * @type Boolean
  * @memberOf RegExp
  * @since Standard ECMA-262 3rd. Edition
  * @since Level 2 Document Object Model Core Definition.  
 */
RegExp.prototype.test=function(string){return false;};
/**
  * property source
  * @type String
  * @memberOf RegExp
  * @since Standard ECMA-262 3rd. Edition
  * @since Level 2 Document Object Model Core Definition. 
 */
RegExp.prototype.source="";
/**
  * property global
  * @type Boolean
  * @memberOf RegExp
  * @since Standard ECMA-262 3rd. Edition
  * @since Level 2 Document Object Model Core Definition.
 */
RegExp.prototype.global=false;

/**
  * property ignoreCase
  * @type Boolean
  * @memberOf RegExp
  * @since Standard ECMA-262 3rd. Edition
  * @since Level 2 Document Object Model Core Definition. 
 */
RegExp.prototype.ignoreCase=false;
/**
  * property multiline
  * @type Boolean
  * @memberOf RegExp
  * @since Standard ECMA-262 3rd. Edition
  * @since Level 2 Document Object Model Core Definition.
 */
RegExp.prototype.multiline=false;
/**
  * property lastIndex
  * @type Number
  * @memberOf RegExp
  * @since Standard ECMA-262 3rd. Edition
  * @since Level 2 Document Object Model Core Definition.
 */
RegExp.prototype.lastIndex=0;
/**
  * Object Error(message)
  * @super Object
  * @constructor
  * @param {String} message
  * @memberOf Error
  * @since Standard ECMA-262 3rd. Edition
  * @since Level 2 Document Object Model Core Definition. 
 */
function Error(message){};
Error.prototype=new Object();
/**
  * property name
  * @type String
  * @memberOf Error
  * @since Standard ECMA-262 3rd. Edition
  * @since Level 2 Document Object Model Core Definition. 
 */
Error.prototype.name="";
/**
  * property message
  * @type String
  * @memberOf Error
  * @since Standard ECMA-262 3rd. Edition
  * @since Level 2 Document Object Model Core Definition. 
 */
Error.prototype.message="";
/**
  * Object EvalError()
  * @super Error
  * @constructor
  *
  * @memberOf EvalError
  * @since Standard ECMA-262 3rd. Edition
  * @since Level 2 Document Object Model Core Definition.
 */
function EvalError(){};
EvalError.prototype=new Error("");
/**
  * Object RangeError()
  * @super Error
  * @constructor
  *
  * @memberOf RangeError
  * @since Standard ECMA-262 3rd. Edition
  * @since Level 2 Document Object Model Core Definition.
 */
function RangeError(){};
RangeError.prototype=new Error("");
/**
  * Object ReferenceError()
  * @super Error
  * @constructor
  *
  * @memberOf ReferenceError
  * @since Standard ECMA-262 3rd. Edition
  * @since Level 2 Document Object Model Core Definition.
 */
function ReferenceError(){};
ReferenceError.prototype=new Error("");
/**
  * Object SyntaxError()
  * @super Error
  * @constructor
  *
  * @memberOf SyntaxError
  * @since Standard ECMA-262 3rd. Edition
  * @since Level 2 Document Object Model Core Definition.
 */
function SyntaxError(){};
SyntaxError.prototype=new Error("");
/**
  * Object TypeError()
  * @super Error
  * @constructor
  *
  * @memberOf TypeError
  * @since Standard ECMA-262 3rd. Edition
  * @since Level 2 Document Object Model Core Definition.
 */
function TypeError(){};
TypeError.prototype=new Error("");
/**
  * Object URIError()
  * @super Error
  * @constructor
  *
  * @memberOf URIError
  * @since Standard ECMA-262 3rd. Edition
  * @since Level 2 Document Object Model Core Definition.
 */
function URIError(){};
URIError.prototype=new Error("");

//support for debugger keyword
var debugger = null;